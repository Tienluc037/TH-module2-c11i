create
    definer = luc@localhost procedure findAllCustomers()
BEGIN   #khai báo bắt đầu của Procedure và kết thúc Procedure

SELECT * FROM customers;

END;

