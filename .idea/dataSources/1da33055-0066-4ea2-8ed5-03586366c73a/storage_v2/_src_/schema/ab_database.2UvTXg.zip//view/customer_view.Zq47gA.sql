create definer = luc@localhost view customer_view as
select `ab_database`.`customers`.`city` AS `city`, `ab_database`.`customers`.`customerName` AS `customername`
from `ab_database`.`customers`;

