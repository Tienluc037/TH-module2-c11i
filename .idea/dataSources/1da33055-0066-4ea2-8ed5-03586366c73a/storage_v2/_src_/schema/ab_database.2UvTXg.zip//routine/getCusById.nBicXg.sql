create
    definer = luc@localhost procedure getCusById(IN cusNum int)
BEGIN

    SELECT * FROM customers WHERE customerNumber = cusNum;

END;

