create definer = luc@localhost view customer_views as
select `ab_database`.`customers`.`customerNumber` AS `customerNumber`,
       `ab_database`.`customers`.`customerName`   AS `customerName`,
       `ab_database`.`customers`.`phone`          AS `phone`
from `ab_database`.`customers`;

